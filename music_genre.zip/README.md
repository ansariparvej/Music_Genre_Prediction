# Music_genre_Prediction 
This model predicts music genre on the basis of given input data.